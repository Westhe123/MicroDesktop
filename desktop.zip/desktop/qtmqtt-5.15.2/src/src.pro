TEMPLATE = subdirs

SUBDIRS = mqtt
