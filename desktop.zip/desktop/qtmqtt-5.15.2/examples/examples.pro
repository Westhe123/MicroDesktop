TEMPLATE = subdirs
SUBDIRS += mqtt
