#include "widget.h"
#include "ui_widget.h"
#include "appswitch.h"
#include <QDebug>
#include <QMessageBox>
#include <QPainter>
#include <QProcess>

namespace
{
// 绘制与界面配色一致的关闭图标，避免依赖额外图片或 SVG 插件。
const QIcon &closeIcon()
{
    static const QIcon icon = [] {
        QPixmap pixmap(64, 64);
        pixmap.fill(Qt::transparent);

        QPainter painter(&pixmap);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.setPen(QPen(QColor("#253247"), 6, Qt::SolidLine,
                            Qt::RoundCap, Qt::RoundJoin));
        painter.drawLine(QPoint(18, 18), QPoint(46, 46));
        painter.drawLine(QPoint(46, 18), QPoint(18, 46));
        return QIcon(pixmap);
    }();
    return icon;
}
}

Widget::Widget(QWidget *parent)
    : QWidget(parent), ui(new Ui::Widget), settings("../MicroDesktop/Desktop.conf", QSettings::IniFormat)
{
    // 初始化 Designer 生成的界面控件。
    ui->setupUi(this);

    // 无边框窗口顶部预留区域属于主窗口本身，设置为白色以消除灰色背景。
    setStyleSheet("QWidget#Widget { background-color: white; }");

    // 应用数量上限已知，提前预留空间，减少 QVector 扩容和元素复制。
    appList.reserve(maxAppCount);
    switchWidgets.reserve(maxAppCount);

    // 隐藏 listWidget 中的滚动条
    ui->listWidget_left->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->listWidget_right->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    // 列表仅用于承载应用开关，不需要选中列表项，避免点击后出现蓝色选中背景。
    ui->listWidget_left->setSelectionMode(QAbstractItemView::NoSelection);
    ui->listWidget_right->setSelectionMode(QAbstractItemView::NoSelection);

    // 读取 Desktop.conf 中保存的窗口尺寸。
    const int configuredWidth = settings.value("Screen/Width").toInt();
    const int configuredHeight = settings.value("Screen/Height").toInt();

    // 顶部填充空白区 50px

    // 去掉列表项的选中、悬停和焦点视觉效果，避免点击后出现色块或边框。
    const QString listStyle =
        "QListWidget{margin-top:76px;border-top:1px solid white;background:white;}"
        "QListWidget::item{background:white;border-bottom:1px solid #edf0f4;}"
        "QListWidget::item:selected,"
        "QListWidget::item:hover,"
        "QListWidget::item:focus{background:transparent;border:none;"
        "border-bottom:1px solid #edf0f4;}";
    ui->listWidget_left->setStyleSheet(listStyle);
    ui->listWidget_right->setStyleSheet(listStyle);
    // 使用左侧列表的右边框作为两列之间的视觉分隔线。
    ui->listWidget_left->setStyleSheet(
        listStyle + "QListWidget{border-right:1px solid #d9dee7;}");
    ui->listWidget_left->setFocusPolicy(Qt::NoFocus);
    ui->listWidget_right->setFocusPolicy(Qt::NoFocus);
    QPushButton *closeButton = new QPushButton(this);
    closeButton->setIcon(closeIcon());
    closeButton->setIconSize(QSize(42, 42));
    closeButton->setGeometry(QRect(800 - 76, 0, 76, 76));
    closeButton->setFlat(true);
    closeButton->setStyleSheet(
        "QPushButton{border:none;background:transparent;border-radius:4px;}"
        "QPushButton:hover{background:#f3f6fa;}"
        "QPushButton:pressed{background:#e9eef5;}");
    // 连接按钮的点击信号到槽函数
    connect(closeButton, &QPushButton::clicked, this, &Widget::closeButton_Clicked_slot);

    // 按 App1、App2……的顺序读取应用配置。
    for (int i = 1; i <= maxAppCount; i++)
    {
        settings.beginGroup(QString("App%1").arg(i));

        // 没有 ID 说明后续没有有效应用配置，结束读取。
        if (!settings.contains("ID"))
        {
            // 不存在ID键值，表示应用程序配置读取结束
            settings.endGroup();
            break;
        }

        // 将配置项复制到内存列表，界面创建阶段直接使用缓存数据。
        AppItem appItem;
        appItem.appId = settings.value("ID", 0).toInt();
        appItem.appName = settings.value("Name").toString();
        appItem.appIconPath = settings.value("Icon").toString();
        appItem.appExecPath = settings.value("Path").toString();
        appList.append(appItem);
        settings.endGroup();
    }

    // 为每个应用创建一个开关，并按顺序分配到左右两个列表。
    for (int i = 0; i < appList.size(); i++)
    {
        QListWidget *list = i < 5 ? ui->listWidget_left : ui->listWidget_right;
        // QListWidgetItem 负责占位，appswitch 负责显示实际内容。
        auto *item = new QListWidgetItem(list);
        item->setSizeHint(QSize(list->width() - 2, 80));

        // 列表作为父对象，窗口销毁时由 Qt 自动回收开关控件。
        auto *switchWidget = new appswitch(list);
        switchWidget->setAppInfo(appList.at(i).appName);
        connect(switchWidget, &appswitch::switchStateChanged,
                this, &Widget::switchStateChanged_slot);
        list->setItemWidget(item, switchWidget);
        switchWidgets.append(switchWidget);
    }
    // 读取当前自启动应用的 ID，并恢复对应开关的选中状态。
    settings.beginGroup("AutoStart");
    qint32 autoStartId = settings.value("AutoStartId").toInt();
    // 结束配置分组，避免后续访问配置时产生意外嵌套路径。
    settings.endGroup();
    // AutoStartId 为 0 表示没有设置自启动程序。
    if (autoStartId > 0)
    {

        // 按真实 appId 查找并恢复对应开关。
        for (int i = 0; i < appList.size(); i++)
        {
            if (autoStartId == appList[i].appId)
            {
                switchWidgets[i]->getpushButton()->setChecked(true);
                switchWidgets[i]->getpushButton()->setIcon(QIcon(":/images/switchon.png"));
            }
        }
    }
}

Widget::~Widget()
{
    // ui 是构造函数中创建的界面对象。
    delete ui;
}

// 处理应用开关状态变化，并同步自启动配置。
void Widget::switchStateChanged_slot(bool checked)
{
    // 找到发出信号的开关控件；信号来源异常时直接忽略。
    auto *source = qobject_cast<appswitch *>(sender());
    if (!source)
        return;

    QPushButton *bt = source->getpushButton();
    // 当前开关打开时关闭其它开关，保证只有一个自启动项。
    for (int i = 0; i < switchWidgets.size(); i++)
    {
        if (bt == switchWidgets[i]->getpushButton()) // 找到当前开关。
        {
            if (checked) // 保存当前开关对应的配置下标。
            {
                settings.beginGroup("AutoStart");
                settings.setValue("AutoStartId", i + 1);
                settings.endGroup();
                continue;
            }
            else // 当前开关关闭时清除自启动配置。
            {
                settings.beginGroup("AutoStart");
                settings.setValue("AutoStartId", 0);
                settings.endGroup();
                continue;
            }
        }
        else
        {
            // 关闭其它开关并恢复关闭状态图标。
            switchWidgets[i]->getpushButton()->setChecked(false);
            switchWidgets[i]->getpushButton()->setIcon(QIcon(":/images/switchoff.png"));
        }
    }
}

// 关闭按钮点击槽函数
void Widget::closeButton_Clicked_slot()
{
    QMessageBox messageBox(QMessageBox::Question,
                           QStringLiteral("退出程序"),
                           QStringLiteral("请选择退出方式："),
                           QMessageBox::NoButton,
                           this);

    // imx6ull 屏幕为 800x480，设置适合触摸操作的弹窗尺寸。
    messageBox.setFixedSize(600, 200);
    messageBox.setStyleSheet(
        "QMessageBox QLabel{font-size:24px;}"
        "QMessageBox QPushButton{font-size:20px;min-width:220px;min-height:55px;}");

    QPushButton *rebootButton = messageBox.addButton(
        QStringLiteral("1. 重启系统"), QMessageBox::AcceptRole);
    QPushButton *laterButton = messageBox.addButton(
        QStringLiteral("2. 稍后重启"), QMessageBox::RejectRole);
    rebootButton->setFixedSize(220, 55);
    laterButton->setFixedSize(220, 55);
    messageBox.setDefaultButton(laterButton);
    messageBox.exec();

    if(messageBox.clickedButton() == rebootButton)
    {
        // 使用独立进程执行 reboot，避免阻塞 Qt 界面线程。
        bool rebootStarted = QProcess::startDetached(
            QStringLiteral("reboot"), QStringList());
        if(!rebootStarted)
        {
            // 开机环境的 PATH 可能不完整，补充常见的绝对路径。
            rebootStarted = QProcess::startDetached(
                QStringLiteral("/sbin/reboot"), QStringList());
        }
        if(!rebootStarted)
        {
            rebootStarted = QProcess::startDetached(
                QStringLiteral("/usr/sbin/reboot"), QStringList());
        }

        if(!rebootStarted)
        {
            qWarning() << "Failed to start reboot command";
            QMessageBox::warning(this,
                                 QStringLiteral("重启失败"),
                                 QStringLiteral("无法执行 reboot，请检查系统权限。"));
            return;
        }

        close();
        return;
    }

    // 选择“稍后重启”时只退出 AutoManager，不重启系统。
    close();
}
