#ifndef APPSWITCH_H
#define APPSWITCH_H

#include <QWidget>
#include <QPushButton>

namespace Ui {
class appswitch;
}

class appswitch : public QWidget
{
    Q_OBJECT

public:
    explicit appswitch(QWidget *parent = nullptr);
    ~appswitch();
    // 设置当前开关对应的应用程序名称。
    void setAppInfo(const QString& appName);
    // 返回内部按钮，供主窗口同步其它开关状态。
    QPushButton* getpushButton();

signals:
    // 用户点击开关后，将状态变化通知主窗口。
    void switchStateChanged(bool checked);

private slots:
    // Qt Designer 自动连接的按钮点击槽函数。
    void on_pushButton_clicked(bool checked);

private:
    Ui::appswitch *ui; // Qt Designer 生成的子界面对象。
};

#endif // APPSWITCH_H
