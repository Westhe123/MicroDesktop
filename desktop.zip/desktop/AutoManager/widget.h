#ifndef WIDGET_H
#define WIDGET_H

#include "appswitch.h"
#include <QWidget>
#include <QSettings>
#include <QPushButton>
#include <QVector>

QT_BEGIN_NAMESPACE
namespace Ui
{
    class Widget;
}
QT_END_NAMESPACE

// 保存配置文件中一个 AppN 分组对应的应用程序信息。
class AppItem
{
public:
    qint32 appId;        // 应用程序 ID。
    QString appName;     // 应用程序名称。
    QString appIconPath; // 应用程序图标路径。
    QString appExecPath; // 应用程序执行路径。
};

// 主窗口：负责读取配置、创建应用开关并保存自启动设置。
class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget() override;

private slots:
    // 关闭按钮点击槽函数
    void closeButton_Clicked_slot();
    // 应用程序开关状态改变槽函数
    void switchStateChanged_slot(bool checked);

private:
    Ui::Widget *ui;                    // Qt Designer 生成的界面对象。
    QSettings settings;                // Desktop.conf 配置文件读写对象。
    static constexpr int maxAppCount = 10; // 最多读取的应用数量。
    QVector<AppItem> appList;           // 应用程序配置列表。
    QVector<appswitch*> switchWidgets; // 与 appList 顺序对应的开关控件列表。
};
#endif // WIDGET_H
