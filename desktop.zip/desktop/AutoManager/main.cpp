#include "widget.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //使用主题功能
    a.setStyle("Fusion");
    Widget w;
    //设置无边框 ，实现全屏桌面的效果
    w.setWindowFlags(Qt::FramelessWindowHint);
    w.show();
    return a.exec();
}
