#include "appswitch.h"
#include "ui_appswitch.h"

namespace
{
// 使用函数内静态对象缓存图标，避免每次点击都重新构造资源图标。
const QIcon &switchOnIcon()
{
    static const QIcon icon(":/images/switchon.png");
    return icon;
}

const QIcon &switchOffIcon()
{
    static const QIcon icon(":/images/switchoff.png");
    return icon;
}
}

appswitch::appswitch(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::appswitch)
{
    // 初始化子界面和按钮控件。
    ui->setupUi(this);
    // 设置按钮为可选中状态，并配置默认的关闭图标。
    ui->pushButton->setCheckable(true); 
    
    ui->pushButton->setIcon(switchOffIcon());
    ui->pushButton->setIconSize(QSize(200 , 60));
    ui->pushButton->setStyleSheet("QPushButton{border:none;}");

    // 统一文字颜色，提升白色背景下的可读性。
    ui->label->setStyleSheet("QLabel{color:#253247;background:transparent;}");
}

appswitch::~appswitch()
{
    // 释放 Designer 创建的子界面对象。
    delete ui;
}


// 设置列表项中显示的应用程序名称。
void appswitch::setAppInfo(const QString& appName)
{
    ui->label->setText(appName);
}
void appswitch::on_pushButton_clicked(bool checked)
{
    // checked 为 true 表示打开，false 表示关闭。
    if(checked)
    {
        // 切换为开启图标。
        ui->pushButton->setIcon(switchOnIcon());
    }
    else
    {
        // 切换为关闭图标。
        ui->pushButton->setIcon(switchOffIcon());
    }
    // 将用户操作转发给主窗口，统一处理配置保存和互斥逻辑。
    emit switchStateChanged(checked);
}

QPushButton* appswitch::getpushButton()
{
    return ui->pushButton;
} 
