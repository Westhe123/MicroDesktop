QT += widgets

CONFIG += c++17

# MSVC 按 UTF-8 解析源码，避免中文注释触发 C4819 及后续级联语法错误。
msvc:QMAKE_CXXFLAGS += /utf-8
msvc:QMAKE_CFLAGS += /utf-8

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    appswitch.cpp \
    main.cpp \
    widget.cpp

HEADERS += \
    appswitch.h \
    widget.h

FORMS += \
    appswitch.ui \
    widget.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target


#设置生成目标名称
TARGET = AutoM
#设置生成文件的输出目录
DESTDIR = $$PWD/../desktop/AutoManager

RESOURCES += \
    images.qrc
