#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QEvent>
#include <QPainter>
#include <QImage>
#include <QPixmap>
#include <QMap>
#include <QMouseEvent>
#include <QDebug>
#include <QProcess>
#include <QSettings>
#include <QVariantAnimation>
#include <QFileInfo>
#include <QHash>
#include <QTimer>


QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE


//存储单个应用程序的配置信息
class AppItem
{
public:
    qint32 appId;       //应用程序的ID
    QString appName;    //应用程序名称
    QString appIconPath;//应用程序图标路径
    QString appExecPath;//应用程序执行路径
    QPixmap appIconPixmap;//已缓存并缩放后的图标
};

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget() ;
    void drawBackground(QPainter &painter);//绘制背景图片
    void drawAppIcon(QPainter &painter,qint32 i, QRect iconRect);//绘制1个app的图标
    void drawAppIcons(QPainter &painter);//绘制apps的图标
    void loadAppConfigList();//加载应用程序的配置信息
    // 延迟启动入口，供 main.cpp 在桌面显示后调用。
    void startAutoStart();

protected:
    bool event(QEvent *event) override;
    void paintEvent(QPaintEvent *event) ;//绘制事件,用于绘制窗口内容
    void mousePressEvent(QMouseEvent *event) ;//鼠标按下事件,用于处理鼠标点击事件
    void mouseReleaseEvent(QMouseEvent *event) ;//鼠标释放事件,用于处理鼠标释放事件
private slots:
    void onPressAnimationValueChanged(const QVariant &value);
    void onPressAnimationFinished();
    void checkWifiStatus();

private:
    static constexpr int otaRestartExitCode = 100;
    QString resolveConfiguredPath(const QString &path) const;
    bool launchApp(const AppItem &appItem);
    void handleProcessFinished(int appId, int exitCode,
                               QProcess::ExitStatus exitStatus);
    void handleProcessError(int appId, QProcess::ProcessError error);
    void setDesktopInputBlocked(bool blocked);
    void refreshDesktop();
    void autoStart();//自动运行应用程序
    bool isWifiConnected() const;
    void drawWifiStatus(QPainter &painter);

    Ui::Widget *ui;

    //============UI 布局常量定义============
    //constexpr 定义常量，避免在运行时计算，提高性能
    static constexpr int appIconWidth = 100;//应用程序的图标宽度
    static constexpr int appIconHeight = 100;//应用程序的图标高度
    static constexpr int appRectWidth = 130;//应用程序的矩形宽度
    static constexpr int appRectHeight = 130;//应用程序的矩形高度

    static constexpr int appOffsetX = 55;//应用程序的图标水平偏移量
    static constexpr int appOffsetY = 80;//应用程序的图标垂直偏移量
    static constexpr int appIconTextFontSize = 16;//应用程序的图标文本字体大小
    static constexpr int maxAppCount = 64;//最多加载的应用数量，避免异常配置占用过多资源

    static constexpr qreal appPressedScale = 0.92;//图标按下时的缩放比例
    static constexpr int appPressAnimationDuration = 80;//图标按下动画时长，单位毫秒
    static constexpr int appReleaseAnimationDuration = 160;//图标释放回弹时长，单位毫秒

    //成员变量
    QVector<AppItem> appList;//应用程序列表
    QMap<int, QRect> appRectMap;//应用程序矩形框映射表

    QSettings settings;//qsettings 用于存储应用程序的配置信息
    //当前按下的应用索引，-1表示没有应用处于按下状态
    int pressedAppIndex = -1;
    //当前图标缩放比例，按下时为0.92，回弹结束后恢复为1.0
    qreal pressScale = 1.0;
    //标记鼠标是否仍然按住应用图标
    bool appPressed = false;
    //释放图标后等待回弹动画完成，再启动对应的应用程序。
    int pendingLaunchIndex = -1;
    //使用QVariantAnimation生成缩放值，并在valueChanged中刷新界面
    QVariantAnimation pressAnimation;
    QPixmap backgroundPixmap;//缓存背景图片，避免每次重绘重复加载
    QSize backgroundPixmapSize;//缓存背景对应的窗口尺寸

    //以应用ID为键保存正在启动或运行中的子进程，防止重复启动。
    QHash<int, QProcess *> runningProcesses;
    //只要有子程序处于启动/运行状态，桌面就不处理鼠标事件。
    bool desktopInputBlocked = false;
    QTimer wifiStatusTimer;
    bool wifiConnected = false;
};
#endif // WIDGET_H
