QT += widgets

CONFIG += c++17 utf8_source

# MSVC 默认使用系统代码页 936，工程源码包含 UTF-8 中文注释。
# 显式指定 UTF-8，避免 C4819 编码警告和由此产生的连锁解析错误。
win32-msvc {
    QMAKE_CXXFLAGS += /utf-8
}

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    main.cpp \
    widget.cpp

HEADERS += \
    gconfig.h \
    widget.h

FORMS += \
    widget.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

#设置生成目标名称
TARGET = Desktop
#设置生成文件的输出目录
DESTDIR = $$PWD/../desktop/MicroDesktop

RESOURCES += \
    images.qrc
