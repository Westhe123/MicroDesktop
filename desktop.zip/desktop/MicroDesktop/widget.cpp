#include "widget.h"
#include "ui_widget.h"
#include "gconfig.h"
#include <QCoreApplication>
#include <QDir>

namespace
{
QPixmap createWifiStatusIcon(bool connected)
{
    QPixmap pixmap(48, 48);
    pixmap.fill(Qt::transparent);

    QPainter painter(&pixmap);
    painter.setRenderHint(QPainter::Antialiasing);
    const QColor iconColor = connected ? QColor("#61d6ff")
                                       : QColor("#c2cad4");
    painter.setPen(QPen(iconColor, 3, Qt::SolidLine, Qt::RoundCap));
    // 三层信号弧线：由外向内表示信号覆盖范围。
    painter.drawArc(QRectF(4, 3, 40, 40), 45 * 16, 90 * 16);
    painter.drawArc(QRectF(10, 9, 28, 28), 45 * 16, 90 * 16);
    painter.drawArc(QRectF(16, 15, 16, 16), 45 * 16, 90 * 16);
    painter.setBrush(iconColor);
    // 中心点稍微上移，缩小与最内层弧线之间的空隙。
    painter.drawEllipse(QRectF(21, 31, 6, 6));

    if(!connected)
    {
        // 斜杠覆盖在弧线和中心点之上，确保断开状态一眼可辨。
        painter.setPen(QPen(QColor(10, 24, 42, 210), 6,
                            Qt::SolidLine, Qt::RoundCap));
        painter.drawLine(QPointF(5, 5), QPointF(43, 43));
        painter.setPen(QPen(QColor("#ff7676"), 3.5,
                            Qt::SolidLine, Qt::RoundCap));
        painter.drawLine(QPointF(5, 5), QPointF(43, 43));
    }

    return pixmap;
}
}

Widget::Widget(QWidget *parent)
    : QWidget(parent) , ui(new Ui::Widget)
    , settings(QDir(QCoreApplication::applicationDirPath()).filePath("Desktop.conf"),
               QSettings::IniFormat)
{
    ui->setupUi(this);

    //QVariantAnimation每一帧输出一个qreal缩放值，驱动自绘图标更新
    pressAnimation.setEasingCurve(QEasingCurve::OutQuad);
    connect(&pressAnimation, &QVariantAnimation::valueChanged,
            this, &Widget::onPressAnimationValueChanged);
    connect(&pressAnimation, &QVariantAnimation::finished,
            this, &Widget::onPressAnimationFinished);


    //判断是否存在配置文件 ，使用程序默认值 ，并创建配置文件
    //如果存在就读取配置文件， 否则使用默认值并保存信息
    if(!settings.contains("Screen/Width") || !settings.contains("Screen/Height"))
    {
        settings.setValue("Screen/Width", GCInstance.screenWidth);
        settings.setValue("Screen/Height", GCInstance.screenHeight);
    }

    GCInstance.screenWidth = settings.value("Screen/Width").toInt();
    GCInstance.screenHeight = settings.value("Screen/Height").toInt();
    resize(GCInstance.screenWidth,GCInstance.screenHeight);

    loadAppConfigList();

    // 桌面启动时立即检测一次，之后每 10 秒刷新 WiFi 状态图标。
    connect(&wifiStatusTimer, &QTimer::timeout,
            this, &Widget::checkWifiStatus);
    checkWifiStatus();
    wifiStatusTimer.start(10000);
}

Widget::~Widget()
{
    delete ui;
}

//加载应用程序的配置信息
void Widget::loadAppConfigList()
{
    appList.clear();

    //按App编号顺序读取配置文件中的应用程序信息
    for (int i = 1; i <= maxAppCount; i++)
    {
        settings.beginGroup(QString("App%1").arg(i));

        //判断当前组是否存在ID键值
        if(!settings.contains("ID"))
        {
            //不存在ID键值，表示应用程序配置读取结束
            settings.endGroup();
            break;
        }

        AppItem appItem;
        appItem.appId = settings.value("ID", 0).toInt();
        appItem.appName = settings.value("Name").toString();
        appItem.appIconPath = resolveConfiguredPath(settings.value("Icon").toString());
        appItem.appExecPath = resolveConfiguredPath(settings.value("Path").toString());
        settings.endGroup();

        //忽略无效ID，避免无效配置影响桌面运行
        if(appItem.appId <= 0)
            continue;

        appItem.appIconPixmap = appItem.appIconPath.isEmpty()
                                    ? QPixmap(":/images/app.png")
                                    : QPixmap(appItem.appIconPath);
        if (appItem.appIconPixmap.isNull())
            appItem.appIconPixmap = QPixmap(":/images/app.png");
        appItem.appIconPixmap = appItem.appIconPixmap.scaled(
            appIconWidth, appIconHeight, Qt::IgnoreAspectRatio,
            Qt::SmoothTransformation);

        qDebug() << "appID:" << appItem.appId
                 << "appName:" << appItem.appName
                 << "appIconPath:" << appItem.appIconPath
                 << "appExecPath:" << appItem.appExecPath;
        appList.append(appItem);
    }
}

//转换配置文件中的相对路径
QString Widget::resolveConfiguredPath(const QString &path) const
{
    if(path.isEmpty())
        return QString();

    if(QFileInfo(path).isAbsolute())
        return QDir::cleanPath(path);

    return QDir(QCoreApplication::applicationDirPath()).absoluteFilePath(path);
}

//启动指定的应用程序。进程由桌面持有，直到退出后再释放。
bool Widget::launchApp(const AppItem &appItem)
{
    if(appItem.appExecPath.isEmpty())
    {
        qWarning() << "Cannot launch app with empty path:"
                   << appItem.appName;
        return false;
    }

    if(runningProcesses.contains(appItem.appId))
    {
        qInfo() << "Application is already running, ignore launch:"
                << appItem.appName << "(ID:" << appItem.appId << ")";
        return false;
    }

    const QString executablePath = appItem.appExecPath;
    QProcess *process = new QProcess(this);
    runningProcesses.insert(appItem.appId, process);

    connect(process, &QProcess::started, this, [this, appId = appItem.appId]() {
        qInfo() << "Application started, ID:" << appId;
    });
    //Qt 5 中 finished 有多个重载，必须明确连接带退出状态的版本。
    connect(process,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this,
            [this, appId = appItem.appId](int exitCode,
                                          QProcess::ExitStatus exitStatus) {
                handleProcessFinished(appId, exitCode, exitStatus);
            });
    connect(process, &QProcess::errorOccurred, this,
            [this, appId = appItem.appId](QProcess::ProcessError error) {
                handleProcessError(appId, error);
            });

    //启动期间也视为“正在运行”，避免连续点击触发多个启动请求。
    setDesktopInputBlocked(true);

    // imx6ull 常用的 linuxfb/eglfs 没有桌面窗口合成器。
    // 不要直接 hide()：隐藏会清空 framebuffer，子程序初始化期间就会黑屏。
    // 保留当前桌面画面，只暂停桌面更新，避免桌面重绘覆盖子程序画面。
    setUpdatesEnabled(false);

    // 让子程序中的相对资源/工具路径以其自身目录为工作目录。
    process->setWorkingDirectory(QFileInfo(executablePath).absolutePath());
    process->start(executablePath, QStringList());
    qInfo() << "Launching application:" << executablePath;
    return true;
}

//获取并记录子进程退出状态，然后释放进程对象并刷新桌面。
void Widget::handleProcessFinished(int appId, int exitCode,
                                   QProcess::ExitStatus exitStatus)
{
    QProcess *process = runningProcesses.take(appId);
    if(process == nullptr)
        return;

    const QString status = exitStatus == QProcess::NormalExit
                               ? QStringLiteral("NormalExit")
                               : QStringLiteral("CrashExit");
    qInfo() << "Application finished, ID:" << appId
            << "exitCode:" << exitCode
            << "exitStatus:" << status;

    process->deleteLater();

    // OTA 完成后，应用使用专用退出码通知桌面重新启动自己。
    // 此时不要恢复桌面刷新和触摸，否则新旧界面切换期间会产生触摸串扰。
    if(exitCode == otaRestartExitCode && exitStatus == QProcess::NormalExit)
    {
        AppItem restartItem;
        bool found = false;
        for(const AppItem &item : appList)
        {
            if(item.appId == appId)
            {
                restartItem = item;
                found = true;
                break;
            }
        }

        if(found)
        {
            qInfo() << "OTA restart requested, relaunch application:"
                    << restartItem.appName;
            // 确保配置/路径已重新读取，使用升级后的可执行文件。
            settings.sync();
            loadAppConfigList();
            for(const AppItem &item : appList)
            {
                if(item.appId == appId)
                {
                    restartItem = item;
                    break;
                }
            }

            // 给旧进程的退出和文件替换留出一个事件循环周期。
            QTimer::singleShot(100, this, [this, restartItem]() {
                if(launchApp(restartItem))
                {
                    qInfo() << "Upgraded application relaunching:"
                            << restartItem.appExecPath;
                }
                else
                {
                    qWarning() << "Failed to relaunch upgraded application:"
                               << restartItem.appName;
                    setDesktopInputBlocked(false);
                    setUpdatesEnabled(true);
                    refreshDesktop();
                    raise();
                    activateWindow();
                }
            });
            return;
        }

        qWarning() << "OTA restart requested, but application ID not found:"
                   << appId;
    }

    if(runningProcesses.isEmpty())
    {
        setDesktopInputBlocked(false);
        setUpdatesEnabled(true);
        refreshDesktop();
        raise();
        activateWindow();
    }
}

//启动失败时没有可靠的退出码，仍需清理占用状态，恢复桌面输入。
void Widget::handleProcessError(int appId, QProcess::ProcessError error)
{
    QProcess *process = runningProcesses.value(appId, nullptr);
    if(process == nullptr)
        return;

    qWarning() << "Application process error, ID:" << appId
               << "error:" << error
               << process->errorString();

    if(error != QProcess::FailedToStart)
        return;

    runningProcesses.remove(appId);
    process->deleteLater();
    if(runningProcesses.isEmpty())
    {
        setDesktopInputBlocked(false);
        setUpdatesEnabled(true);
        refreshDesktop();
        raise();
        activateWindow();
    }
}

//运行子程序时，拦截桌面的全部鼠标事件，避免再次触发图标操作。
void Widget::setDesktopInputBlocked(bool blocked)
{
    if(desktopInputBlocked == blocked)
        return;

    desktopInputBlocked = blocked;
    if(blocked)
    {
        pressedAppIndex = -1;
        appPressed = false;
    }
    update();
}

//重新读取桌面配置和图标缓存，使子程序对配置的修改在退出后立即生效。
void Widget::refreshDesktop()
{
    settings.sync();

    const int configuredWidth = settings.value("Screen/Width",
                                               GCInstance.screenWidth).toInt();
    const int configuredHeight = settings.value("Screen/Height",
                                                GCInstance.screenHeight).toInt();
    if(configuredWidth > 0 && configuredHeight > 0
        && (configuredWidth != GCInstance.screenWidth
            || configuredHeight != GCInstance.screenHeight))
    {
        GCInstance.screenWidth = configuredWidth;
        GCInstance.screenHeight = configuredHeight;
        resize(configuredWidth, configuredHeight);
    }

    loadAppConfigList();
    appRectMap.clear();
    update();
}

bool Widget::isWifiConnected() const
{
    // 开机启动时 PATH 可能尚未完整配置，依次尝试常见安装位置。
    const QStringList commands = QStringList()
                                 << QStringLiteral("iwgetid")
                                 << QStringLiteral("/sbin/iwgetid")
                                 << QStringLiteral("/usr/sbin/iwgetid")
                                 << QStringLiteral("/bin/iwgetid");

    for(const QString &command : commands)
    {
        QProcess process;
        process.start(command, QStringList() << QStringLiteral("-r"));
        if(!process.waitForStarted(300))
            continue;
        if(!process.waitForFinished(300))
        {
            process.kill();
            continue;
        }

        if(process.exitStatus() == QProcess::NormalExit
            && process.exitCode() == 0
            && !QString::fromLocal8Bit(process.readAllStandardOutput())
                    .trimmed().isEmpty())
            return true;
    }

    return false;
}

void Widget::checkWifiStatus()
{
    const bool connected = isWifiConnected();
    if(wifiConnected == connected)
        return;

    wifiConnected = connected;
    update();
    qInfo() << (wifiConnected ? "WiFi connected" : "WiFi disconnected");
}

void Widget::drawWifiStatus(QPainter &painter)
{
    // 顶部保留一块独立状态区域，避开第一行应用图标，同时与桌面边缘留出边距。
    const QRect panelRect(width() - 132, 14, 116, 52);
    painter.save();
    painter.setRenderHint(QPainter::Antialiasing);

    painter.setPen(QPen(QColor(255, 255, 255, 45), 1));
    painter.setBrush(QColor(10, 24, 42, 150));
    painter.drawRoundedRect(panelRect, 16, 16);

    const QRect iconRect(panelRect.left() + 7, panelRect.top() + 2, 48, 48);
    painter.drawPixmap(iconRect, createWifiStatusIcon(wifiConnected));

    painter.setPen(QColor(255, 255, 255, 225));
    painter.setFont(QFont("Microsoft YaHei", 11, QFont::DemiBold));
    painter.drawText(QRect(panelRect.left() + 56, panelRect.top() + 7, 54, 18),
                     Qt::AlignLeft | Qt::AlignVCenter, QStringLiteral("WiFi"));

    painter.setPen(wifiConnected ? QColor("#8ce7bd") : QColor("#ffb0b0"));
    painter.setFont(QFont("Microsoft YaHei", 9));
    painter.drawText(QRect(panelRect.left() + 56, panelRect.top() + 27, 54, 17),
                     Qt::AlignLeft | Qt::AlignVCenter,
                     wifiConnected ? QStringLiteral("已连接")
                                   : QStringLiteral("未连接"));
    painter.restore();
}

// 对外的延迟启动入口，避免 main.cpp 直接依赖内部自启动实现。
void Widget::startAutoStart()
{
    autoStart();
}

//自动运行应用程序
// [AutoStart]
// AutoStartId=1
void Widget::autoStart()
{
    //检查是否设置了自动运行应用程序
    if(settings.value("AutoStart/AutoStartId",0).toInt() == 0)
    {
        //未设置自动运行应用程序，直接返回
        return;
    }

    //遍历应用程序列表
    for (qint32 i = 0; i < appList.size(); i++)
    {
        //根据AutoStartID来启动我们的应用程序
        if(appList[i].appId == settings.value("AutoStart/AutoStartId",0).toInt())
        {
            //启动应用程序
            launchApp(appList[i]);
        }
    }
}

//绘制事件,用于绘制窗口内容
void Widget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);//未使用事件参数，避免编译警告

    QPainter painter(this);
    painter.setRenderHints(QPainter::Antialiasing);     //启用抗锯齿
    painter.setRenderHints(QPainter::SmoothPixmapTransform);    //平滑像素转换
    //绘制背景图片
    drawBackground(painter);
    //绘制app的图标
    drawAppIcons(painter);
    //绘制右上角 WiFi 连接状态图标
    drawWifiStatus(painter);
}

bool Widget::event(QEvent *event)
{
    if(desktopInputBlocked || pendingLaunchIndex >= 0)
    {
        switch(event->type())
        {
        case QEvent::MouseButtonPress:
        case QEvent::MouseButtonRelease:
        case QEvent::MouseButtonDblClick:
        case QEvent::MouseMove:
        case QEvent::Wheel:
            return true;
        default:
            break;
        }
    }

    return QWidget::event(event);
}

//鼠标按压事件
void Widget::mousePressEvent(QMouseEvent *event)
{
    if(desktopInputBlocked || pendingLaunchIndex >= 0)
    {
        event->ignore();
        return;
    }

    //每次新的按下事件都先清除上一次残留的按压状态。
    pressedAppIndex = -1;
    appPressed = false;
    //检查是否点击了应用程序图标
    for (qint32 i = 0; i < appList.size(); i++)
    {
        if (appRectMap.contains(i) && appRectMap[i].contains(event->pos()))
        {
            //启动应用程序
            //记录按下的应用，并立即显示缩小反馈。
            pressedAppIndex = i;
            appPressed = true;
            //按下：从当前比例缩小到0.92，并保持按压状态。
            pressAnimation.stop();
            pressAnimation.setEasingCurve(QEasingCurve::OutQuad);
            pressAnimation.setDuration(appPressAnimationDuration);
            pressAnimation.setStartValue(pressScale);
            pressAnimation.setEndValue(appPressedScale);
            pressAnimation.start();
            qDebug() << "click app:" << appList[i].appName;
            break;
        }
    }
}

//鼠标释放事件
void Widget::mouseReleaseEvent(QMouseEvent *event)
{
    if(desktopInputBlocked || pendingLaunchIndex >= 0)
    {
        event->ignore();
        return;
    }

    //保存按下索引，确保只有按下和释放的是同一个图标才会启动应用。
    const int releasedAppIndex = pressedAppIndex;
    //检查是否点击了应用程序图标
    for (qint32 i = 0; i < appList.size(); i++)
    {
        if (i == releasedAppIndex && appRectMap.contains(i) && appRectMap[i].contains(event->pos()))
        {
            //先记录待启动的应用，等待回弹动画完成后再启动。
            qDebug() << "release app:" << appList[i].appName;
            pendingLaunchIndex = releasedAppIndex;
            break;
        }
    }
    //释放后执行0.92 -> 1.0的缩放回弹动画。
    appPressed = false;
    //松开：从当前比例回弹到1.0。
    if(releasedAppIndex >= 0)
    {
        pressAnimation.stop();
        //释放时使用带轻微超调的曲线，形成自然的回弹效果。
        pressAnimation.setEasingCurve(QEasingCurve::OutBack);
        pressAnimation.setDuration(appReleaseAnimationDuration);
        pressAnimation.setStartValue(pressScale);
        pressAnimation.setEndValue(1.0);
        pressAnimation.start();
    }
}

//QVariantAnimation的值变化槽：同步缩放比例并刷新自绘界面。
void Widget::onPressAnimationValueChanged(const QVariant &value)
{
    pressScale = value.toReal();
    update();
}

//QVariantAnimation的完成槽：回弹结束后清除当前按下图标索引。
void Widget::onPressAnimationFinished()
{
    if(!appPressed)
    {
        const int launchIndex = pendingLaunchIndex;
        pendingLaunchIndex = -1;
        pressedAppIndex = -1;
        update();

        // 回弹已经完成，此时再暂停桌面更新并启动子程序，保证视觉反馈完整。
        if(launchIndex >= 0 && launchIndex < appList.size())
            launchApp(appList.at(launchIndex));
    }
}

//绘制背景图片
void Widget::drawBackground(QPainter &painter)
{
    //只有窗口尺寸变化时才重新加载和缩放背景，减少动画期间的重复分配
    if(backgroundPixmap.isNull() || backgroundPixmapSize != rect().size())
    {
        backgroundPixmap = QPixmap(":/images/back.png");
        backgroundPixmap = backgroundPixmap.scaled(rect().size(),
                                                   Qt::IgnoreAspectRatio,
                                                   Qt::SmoothTransformation);
        backgroundPixmapSize = rect().size();
    }
    painter.drawPixmap(rect(), backgroundPixmap);
}

//绘制apps的图标
void Widget::drawAppIcons(QPainter &painter)
{
    //设置字体 16号字体 微软雅黑
    painter.setFont(QFont("Microsoft YaHei",appIconTextFontSize));
    //设置字体颜色
    painter.setPen(Qt::white);
    appRectMap.clear();

    //计算应用程序的区域 800 / 4
    const int spacing = GCInstance.screenWidth / GCInstance.appIconCols - 15;
    //遍历应用程序列表，绘制图标
    for(qint32 i = 0; i < appList.size(); i++)
    {
        //计算应用程序的行号和列号
        int row = i / GCInstance.appIconCols;
        int col = i % GCInstance.appIconCols;

        //计算应用程序的x坐标和y坐标
        int currentAppX = spacing * col + appOffsetX;
        int currentAppY = spacing * row + appOffsetY;

        //计算图标在矩形框的居中位置
        int offsetX = (appRectWidth - appIconWidth) / 2;
        //创建图标和文本的矩形区域
        QRect iconRect(currentAppX+offsetX,currentAppY,appIconWidth,appIconHeight);
        QRect textRect(currentAppX+offsetX,iconRect.bottom(),appIconWidth,30);

        //仅对当前按下的图标应用缩放，其他图标保持原始大小。
        if(i == pressedAppIndex)
        {
            const QPointF center = iconRect.center();
            painter.save();
            painter.translate(center);
            painter.scale(pressScale, pressScale);
            painter.translate(-center);
        }

        drawAppIcon(painter ,i , iconRect);//绘制1个app的图标
        //绘制文本
        painter.drawText(textRect,Qt::AlignCenter|Qt::AlignTop,appList[i].appName);
        if(i == pressedAppIndex)
            painter.restore();

        //构建1个app的矩形框
        QRect appRect(currentAppX,currentAppY,appRectWidth,appRectHeight);
        //painter.drawRect(appRect);//绘制应用程序矩形框
        //保存矩形框
        appRectMap.insert(i,appRect); //保存应用程序矩形框
    }
}

//绘制1个app的图标
void Widget::drawAppIcon(QPainter &painter,qint32 i, QRect iconRect)
{
    // 图标已在加载配置时缓存并缩放，这里只负责绘制。
    painter.drawPixmap(iconRect, appList[i].appIconPixmap);
}
