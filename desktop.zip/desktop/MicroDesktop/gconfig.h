#ifndef GCONFIG_H
#define GCONFIG_H

#include <QString>

//加线程安全的单例模式宏
//配置文件宏
//提供全局配置实例的便捷访问方式
#define GCInstance ( GConfig::Instance() )

//全局配置文件
//全局配置文件类
//该类用于存储全局配置信息
class GConfig
{
public:
    qint32 screenWidth = 800;//屏幕宽度
    qint32 screenHeight = 480;//屏幕高度
    // 桌面显示图标的行数
    qint32 appIconRows = 2;//桌面显示图标的行数
    qint32 appIconCols = 4;//桌面显示图标的列数
    
    //获取单例对象
    //该方法用于获取全局配置文件对象
    //返回值：全局配置文件对象
    //该方法为静态方法，无需创建对象即可调用
    static GConfig &Instance()//获取单例对象
    {
        static GConfig instance;//静态局部变量，确保线程安全的单例模式
        return instance;
    }

private:
    GConfig()//构造函数私有化，防止外部创建对象
    {
    }

};



#endif // GCONFIG_H
