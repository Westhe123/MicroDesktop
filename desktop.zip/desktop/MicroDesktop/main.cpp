#include "widget.h"
#include "gconfig.h"
#include <QApplication>
#include <QTimer>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //使用主题功能
    a.setStyle("Fusion");
    Widget w;
    //设置无边框 ，实现全屏桌面的效果
    w.setWindowFlags(Qt::FramelessWindowHint);
    w.resize(GCInstance.screenWidth,GCInstance.screenHeight);
    w.show();

    // 必须等桌面窗口完成显示后再启动自启动程序。
    // 否则子窗口可能先显示，随后被全屏桌面窗口覆盖。
    QTimer::singleShot(200, &w, &Widget::startAutoStart);

    return QApplication::exec();
}
