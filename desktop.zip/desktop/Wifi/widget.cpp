#include "widget.h"
#include "ui_widget.h"

#include <QFileInfo>
#include <QStandardPaths>

namespace
{
QString findUtility(const QString &name)
{
    const QString fromPath = QStandardPaths::findExecutable(name);
    if (!fromPath.isEmpty())
        return fromPath;

    const QStringList commonPaths = QStringList()
                                    << QStringLiteral("/sbin/")
                                    << QStringLiteral("/usr/sbin/")
                                    << QStringLiteral("/bin/")
                                    << QStringLiteral("/usr/bin/");
    for (const QString &path : commonPaths)
    {
        const QString candidate = path + name;
        if (QFileInfo::exists(candidate))
            return candidate;
    }
    return QString();
}

bool runUtility(const QString &name, const QStringList &arguments,
                int timeout, QByteArray *output = nullptr)
{
    const QString program = findUtility(name);
    if (program.isEmpty())
        return false;

    QProcess process;
    process.start(program, arguments);
    if (!process.waitForStarted(timeout) || !process.waitForFinished(timeout))
    {
        if (process.state() != QProcess::NotRunning)
            process.kill();
        return false;
    }
    if (output != nullptr)
        *output = process.readAllStandardOutput();
    return process.exitStatus() == QProcess::NormalExit
           && process.exitCode() == 0;
}

bool startUtilityDetached(const QString &name, const QStringList &arguments)
{
    const QString program = findUtility(name);
    return !program.isEmpty()
           && QProcess::startDetached(program, arguments);
}

QString escapeWpaValue(QString value)
{
    value.replace(QStringLiteral("\\"), QStringLiteral("\\\\"));
    value.replace(QStringLiteral("\""), QStringLiteral("\\\""));
    value.replace(QStringLiteral("\n"), QString());
    value.replace(QStringLiteral("\r"), QString());
    return value;
}
}

Widget::Widget(QWidget *parent)
    : QWidget(parent), ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->pushButton_connect->setCheckable(true);
    ui->lineEdit_passwd->setEchoMode(QLineEdit::Password);
    ui->lineEdit_ssid->setText("iPhone");
    ui->lineEdit_passwd->setText("123456hh");

    wifiConnectTimer.setInterval(250);
    connect(&wifiConnectTimer, &QTimer::timeout,
            this, &Widget::pollWifiConnection);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_quit_clicked()
{
    close();
}

void Widget::on_pushButton_connect_clicked(bool checked)
{
    if (!checked)
    {
        wifiConnectTimer.stop();
        ui->pushButton_connect->setText("连接");
        ui->pushButton_connect->setEnabled(true);
        return;
    }

    wifi_name = ui->lineEdit_ssid->text().trimmed();
    wifi_password = ui->lineEdit_passwd->text();
    if (wifi_name.isEmpty() || wifi_password.isEmpty())
    {
        QMessageBox::warning(this, "警告", "请输入 wifi 名称和密码");
        ui->pushButton_connect->setChecked(false);
        return;
    }

    // 部分 Buildroot/wpa_supplicant 精简版本不支持 ctrl_interface、
    // update_config 等全局字段，只保留通用的 network 配置块。
    const QString wpaConfig = "network={\n"
                              "    ssid=\"" + escapeWpaValue(wifi_name) + "\"\n"
                                                            "    psk=\"" + escapeWpaValue(wifi_password) + "\"\n"
                                                                "}\n";
    QFile file("/etc/wpa_supplicant.conf");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QMessageBox::warning(this, "警告", "无法打开 wpa_supplicant.conf 文件");
        ui->pushButton_connect->setChecked(false);
        return;
    }
    QTextStream stream(&file);
    stream << wpaConfig;
    file.close();

    // 手机热点首次连接时，必须先打开无线接口并清理旧的认证进程。
    runUtility(QStringLiteral("ip"),
               QStringList() << QStringLiteral("link")
                             << QStringLiteral("set")
                             << QStringLiteral("wlan0")
                             << QStringLiteral("up"), 1000);
    runUtility(QStringLiteral("ifconfig"),
               QStringList() << QStringLiteral("wlan0")
                             << QStringLiteral("up"), 1000);
    // 配置文件已经被更新，直接重启 supplicant，避免旧配置继续生效。
    if (!runUtility(QStringLiteral("killall"),
                    QStringList() << QStringLiteral("wpa_supplicant"), 1000))
    {
        // 兼容没有 killall、但提供 pkill 的精简系统。
        runUtility(QStringLiteral("pkill"),
                   QStringList() << QStringLiteral("wpa_supplicant"), 1000);
    }
    if (!startWifiSupplicant())
    {
        QMessageBox::warning(this, "警告",
                             "无法启动 WiFi 认证服务，请检查 wpa_supplicant");
        ui->pushButton_connect->setChecked(false);
        return;
    }

    // 异步检测，连接过程中不会阻塞界面线程。
    ui->pushButton_connect->setText("连接中...");
    ui->pushButton_connect->setEnabled(false);
    wifiConnectElapsed = 0;
    wifiConnectTimer.start();
}

void Widget::pollWifiConnection()
{
    if (isWifiAssociated())
    {
        startDhcpClient();
        finishWifiConnection(true);
        return;
    }

    wifiConnectElapsed += wifiConnectTimer.interval();
    if (wifiConnectElapsed >= 30000)
        finishWifiConnection(false);
}

bool Widget::isWifiAssociated() const
{
    QByteArray status;
    if (runUtility(QStringLiteral("wpa_cli"),
                   QStringList() << QStringLiteral("-i")
                                 << QStringLiteral("wlan0")
                                 << QStringLiteral("status"),
                   400, &status)
        && status.contains("wpa_state=COMPLETED"))
        return true;

    QByteArray linkInfo;
    if (runUtility(QStringLiteral("iw"),
                   QStringList() << QStringLiteral("dev")
                                 << QStringLiteral("wlan0")
                                 << QStringLiteral("link"),
                   400, &linkInfo)
        && linkInfo.contains("Connected to"))
        return true;

    QByteArray connectedSsid;
    return runUtility(QStringLiteral("iwgetid"),
                      QStringList() << QStringLiteral("-r"),
                      400, &connectedSsid)
           && !QString::fromLocal8Bit(connectedSsid).trimmed().isEmpty();
}

bool Widget::startWifiSupplicant()
{
    const QString program = findUtility(QStringLiteral("wpa_supplicant"));
    if (program.isEmpty())
        return false;

    return QProcess::startDetached(program,
                                   QStringList() << QStringLiteral("-B")
                                                 << QStringLiteral("-Dnl80211")
                                                 << QStringLiteral("-iwlan0")
                                                 << QStringLiteral("-c/etc/wpa_supplicant.conf"));
}

void Widget::startDhcpClient()
{
    // 认证成功后获取 IP；后台执行，不阻塞界面。
    startUtilityDetached(QStringLiteral("udhcpc"),
                         QStringList() << QStringLiteral("-i")
                                       << QStringLiteral("wlan0")
                                       << QStringLiteral("-n"));
}

void Widget::finishWifiConnection(bool connected)
{
    wifiConnectTimer.stop();
    ui->pushButton_connect->setEnabled(true);

    if (connected)
    {
        QMessageBox::information(this, "提示", "WiFi 连接成功");
        ui->pushButton_connect->setText("已连接");
        ui->lineEdit_ssid->setEnabled(false);
        ui->lineEdit_passwd->setEnabled(false);
    }
    else
    {
        QMessageBox::warning(this, "警告", "WiFi 连接失败（超时）");
        ui->pushButton_connect->setText("连接");
        ui->lineEdit_ssid->setEnabled(true);
        ui->lineEdit_passwd->setEnabled(true);
        ui->pushButton_connect->setChecked(false);
    }
}
