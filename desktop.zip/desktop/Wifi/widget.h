#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QString>
#include <QDebug>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QProcess>
#include <QStringList>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_pushButton_connect_clicked(bool checked);

    void on_pushButton_quit_clicked();

    void pollWifiConnection();

private:
    bool isWifiAssociated() const;
    bool startWifiSupplicant();
    void startDhcpClient();
    void finishWifiConnection(bool connected);

    Ui::Widget *ui;
    QString wifi_name;
    QString wifi_password;
    QTimer wifiConnectTimer;
    int wifiConnectElapsed = 0;
};
#endif // WIDGET_H
