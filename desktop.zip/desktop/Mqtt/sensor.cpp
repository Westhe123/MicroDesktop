#include "sensor.h"
#include "ui_sensor.h"
#include <QApplication>
#include <QDir>
#include <QFileInfo>
#include <QCoreApplication>
#include <QComboBox>
#include <QAbstractSocket>

Widget::Widget(QWidget *parent)
    : QWidget(parent), ui(new Ui::Widget),
    settings(QDir(QCoreApplication::applicationDirPath())
                 .absoluteFilePath("../MicroDesktop/Desktop.conf"),
             QSettings::IniFormat)
{
    ui->setupUi(this);

    // 创建 OTA 模块
    httpOta = new HttpOta(this, &settings);
    connect(httpOta, &HttpOta::progress, this, &Widget::onOtaProgress);
    connect(httpOta, &HttpOta::statusMessage, this, &Widget::onOtaStatusMessage);
    connect(httpOta, &HttpOta::finished, this, &Widget::onOtaFinished);

    this->initUi();

    // 读取 setting 配置文件
    // ============ 设置窗口尺寸 ============
    QString tocken = settings.value("Tocken/tocken").toString();
    qDebug() << "tocken:" << tocken;
    qDebug() << "server:" << ui->comboBox_server->currentText();

    // 初始化定时器
    timer = new QTimer(this);
    // 连接定时器信号到槽函数
    connect(timer, &QTimer::timeout, this, &Widget::timer_timeout);

    reconnectTimer.setInterval(3000);
    connect(&reconnectTimer, &QTimer::timeout, this, [this]() {
        if (!userRequestedDisconnect
            && ui->pushButton_open->isChecked()
            && systemNetworkOnline
            && (mqttclient == nullptr
                || mqttclient->state() == QMqttClient::Disconnected))
            startMqttConnection();
    });

    // 网络断开时，QMqttClient 可能要等 MQTT 保活超时后才发出
    // Disconnected。使用 QNetworkInterface 定期复核，避免界面长时间
    // 停留在“断开连接”状态，同时停止断线期间的数据上报。
    connectionWatchdogTimer.setInterval(2000);
    connect(&connectionWatchdogTimer, &QTimer::timeout, this, [this]() {
        const bool online = isSystemNetworkOnline();
        if (online)
        {
            // 首次启动时网络可能尚未完成初始化，首次检测到离线不拦截
            // 初始连接；后续从在线变为离线时才立即处理。
            networkOnlineObserved = true;
            if (!systemNetworkOnline)
                handleNetworkStateChanged(true);
        }
        else if (networkOnlineObserved && systemNetworkOnline)
        {
            handleNetworkStateChanged(false);
        }

        if (mqttclient == nullptr || systemNetworkOnline)
            return;

        if (mqttclient->state() != QMqttClient::Disconnected)
        {
            qWarning() << "network is offline, closing stale MQTT connection";
            timer->stop();
            ui->comboBox_server->setEnabled(true);
            if (!userRequestedDisconnect && ui->pushButton_open->isChecked())
                ui->pushButton_open->setText(tr("网络断开，等待重连..."));
            mqttclient->disconnectFromHost();
        }
    });
    connectionWatchdogTimer.start();
    connect(ui->comboBox_server,
            QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &Widget::handleServerChanged);

    // 读取led1 的状态
    QProcess process;
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/class/leds/led1/brightness"));
    process.waitForFinished(); // 等待程序执行完成
    // 读取进程输出的结果
    QString str = process.readAllStandardOutput();
    bool ok;
    int value = str.toInt(&ok);
    if (ok) // true 转换成功
    {
        qDebug() << "led1 value = " << value;
        if (value == 1)
        {
            ui->pushButton_led1->setChecked(true); // 按钮按下
            ui->pushButton_led1->setStyleSheet(
                "QPushButton#pushButton_led1 {"
                "  border: none;"
                "  border-image: url(:/images/led1on.png) 1 1 1 1 stretch stretch;"
                "}");
        }
        else
        {
            ui->pushButton_led1->setChecked(false); // 按钮抬起
            ui->pushButton_led1->setStyleSheet(
                "QPushButton#pushButton_led1 {"
                "  border: none;"
                "  border-image: url(:/images/led1off.png) 1 1 1 1 stretch stretch;"
                "}");
        }
    }
    else
    {
        qDebug() << "failed to led1 value";
    }

    // 读取led2 的状态
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/class/leds/led2/brightness"));
    process.waitForFinished(); // 等待程序执行完成
    // 读取进程输出的结果
    str = process.readAllStandardOutput();
    value = str.toInt(&ok);
    if (ok) // true 转换成功
    {
        qDebug() << "led2 value = " << value;
        if (value == 1)
        {
            ui->pushButton_led2->setChecked(true); // 按钮按下
            ui->pushButton_led2->setStyleSheet(
                "QPushButton#pushButton_led2 {"
                "  border: none;"
                "  border-image: url(:/images/led2on.png) 1 1 1 1 stretch stretch;"
                "}");
        }
        else
        {
            ui->pushButton_led2->setChecked(false); // 按钮抬起
            ui->pushButton_led2->setStyleSheet(
                "QPushButton#pushButton_led2 {"
                "  border: none;"
                "  border-image: url(:/images/led2off.png) 1 1 1 1 stretch stretch;"
                "}");
        }
    }
    else
    {
        qDebug() << "failed to led2 value";
    }

    // 读取extio1 的状态
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/class/leds/extio1/brightness"));
    process.waitForFinished(); // 等待程序执行完成
    // 读取进程输出的结果
    str = process.readAllStandardOutput();
    value = str.toInt(&ok);
    if (ok) // true 转换成功
    {
        qDebug() << "extio1 value = " << value;
        if (value == 1)
        {
            ui->pushButton_beep->setChecked(true); // 按钮按下
            ui->pushButton_beep->setStyleSheet(
                "QPushButton#pushButton_beep {"
                "  border: none;"
                "  border-image: url(:/images/extio1on.png) 1 1 1 1 stretch stretch;"
                "}");
        }
        else
        {
            ui->pushButton_beep->setChecked(false); // 按钮抬起
            ui->pushButton_beep->setStyleSheet(
                "QPushButton#pushButton_beep {"
                "  border: none;"
                "  border-image: url(:/images/extio1off.png) 1 1 1 1 stretch stretch;"
                "}");
        }
    }
    else
    {
        qDebug() << "failed to extio1 value";
    }

    // 读取beep 的状态
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/class/leds/beep/brightness"));
    process.waitForFinished(); // 等待程序执行完成
    // 读取进程输出的结果
    str = process.readAllStandardOutput();
    value = str.toInt(&ok);
    if (ok) // true 转换成功
    {
        qDebug() << "beep value = " << value;
        if (value == 1)
        {
            ui->pushButton_beep->setChecked(true); // 按钮按下
            ui->pushButton_beep->setStyleSheet(
                "QPushButton#pushButton_beep {"
                "  border: none;"
                "  border-image: url(:/images/beepon.png) 1 1 1 1 stretch stretch;"
                "}");
        }
        else
        {
            ui->pushButton_beep->setChecked(false); // 按钮抬起
            ui->pushButton_beep->setStyleSheet(
                "QPushButton#pushButton_beep {"
                "  border: none;"
                "  border-image: url(:/images/beepoff.png) 1 1 1 1 stretch stretch;"
                "}");
        }
    }
    else
    {
        qDebug() << "failed to beep value";
    }

    // 按下按钮 ， 触发槽函数 on_pushButton_clicked()
    // 保持原有的开机自动连接功能，并同步按钮状态。
    ui->pushButton_open->setChecked(true);
    on_pushButton_open_clicked(true); // 按钮按下，触发连接
}

Widget::~Widget()
{
    delete ui;
}

// 定时器超时槽函数
void Widget::timer_timeout()
{
#ifdef __arm__

    // 读取aht20 温度和湿度数据
    // 23.4,15.3
    QProcess process;
    process.start(QStringLiteral("./aht20"), QStringList()); // 使用相对路径，aht20 在同目录下
    process.waitForFinished();
    QString output = QString::fromUtf8(process.readAllStandardOutput());
    QStringList list = output.split(",");
    QString temp;
    QString hum;
    if (list.size() >= 2)
    {
        temp = list[0].trimmed();                 // 23.4
        hum = list[1].trimmed();                  // 15.3
        ui->pushButton_temp->setText(temp + "℃"); // 带上单位
        ui->pushButton_hum->setText(hum + "%");   // 带上单位
    }

    // vr 电位器的值
    // 读取vr 电位器的值
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/bus/iio/devices/iio:device0/in_voltage3_raw"));
    process.waitForFinished();
    QString vr_output = QString::fromUtf8(process.readAllStandardOutput());
    QString vr_value = QString::asprintf("%.2f", vr_output.trimmed().toInt() * 3.3 / 4096);
    ui->pushButton_vr->setText(vr_value + "V"); // 带上单位

    // 读取ina226 vol的值
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/class/hwmon/hwmon0/in1_input"));
    process.waitForFinished();
    QString vol_output = QString::fromUtf8(process.readAllStandardOutput());
    QString vol_value = QString::asprintf("%.2f", vol_output.trimmed().toInt() / 1000.0);
    ui->pushButton_vol->setText(vol_value + "V"); // 带上单位

    // 读取ina226 电流的值
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/class/hwmon/hwmon0/curr1_input"));
    process.waitForFinished();
    QString cur_output = QString::fromUtf8(process.readAllStandardOutput());
    QString cur_value = QString::asprintf("%.0f", cur_output.trimmed().toInt() / 1.0);
    ui->pushButton_cur->setText(cur_value + "MA"); // 带上单位

    // 读取ina226 功率的值
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/class/hwmon/hwmon0/power1_input"));
    process.waitForFinished();
    QString pow_output = QString::fromUtf8(process.readAllStandardOutput());
    QString pow_value = QString::asprintf("%.2f", pow_output.trimmed().toInt() / 1000.0 / 1000.0);
    ui->pushButton_pw->setText(pow_value + "W"); // 带上单位

    // 读取温度传感器数据 CPU 温度
    process.start(QStringLiteral("cat"),
                  QStringList() << QStringLiteral("/sys/class/thermal/thermal_zone0/temp"));
    process.waitForFinished();
    QString temp_output = QString::fromUtf8(process.readAllStandardOutput());
    QString temp_value = QString::asprintf("%.0f", temp_output.trimmed().toInt() / 1000.0);
    ui->pushButton_cpu->setText(temp_value + "℃"); // 带上单位

    QJsonObject sensor_json;
    // 上行主题： v1/devices/me/telemetry
    // {TP:20.5,RH:15.3,VR:2.5,VOL:4.2,CUR:100,PW:10.0,CPU:20.5}
    sensor_json.insert("TP", temp.toFloat());
    sensor_json.insert("RH", hum.toFloat());
    sensor_json.insert("VR", vr_value.toFloat());
    sensor_json.insert("VO", vol_value.toFloat());
    sensor_json.insert("CU", cur_value.toFloat());
    sensor_json.insert("PW", pow_value.toFloat());
    sensor_json.insert("CPU", temp_value.toFloat());
    QJsonDocument doc;                                        // 定义1个json字符串
    doc.setObject(sensor_json);                               // 初始化1个json字符串
    QByteArray cmdArray = doc.toJson(QJsonDocument::Compact); // 把json字符串 转换成 bytearray
    if (mqttclient != nullptr)
    {
        mqttclient->publish(upload_topic1, cmdArray, 1); // QoS 1，可靠发送数据
    }
#else
    QJsonObject sensor_json;
    // 上行主题： v1/devices/me/telemetry
    // {TP:20.5,RH:15.3,VR:2.5,VOL:4.2,CUR:100,PW:10.0,CPU:20.5}
    int temp_value = 20;
    int hum = 15;
    float vr_value = 2.5;
    float vol_value = 4.2;
    float cur_value = 100.0;
    float pow_value = 10.0;
    int cpu_value = 20;
    sensor_json.insert("TP", temp_value);
    sensor_json.insert("RH", hum);
    sensor_json.insert("VR", vr_value);
    sensor_json.insert("VOL", vol_value);
    sensor_json.insert("CUR", cur_value);
    sensor_json.insert("PW", pow_value);
    sensor_json.insert("CPU", cpu_value);
    QJsonDocument doc;                                        // 定义1个json字符串
    doc.setObject(sensor_json);                               // 初始化1个json字符串
    QByteArray cmdArray = doc.toJson(QJsonDocument::Compact); // 把json字符串 转换成 bytearray
    if (mqttclient != nullptr)
    {
        mqttclient->publish(upload_topic1, cmdArray, 1); // QoS 1，可靠发送数据
    }

    qDebug() << "upload_topic1:" << cmdArray;
#endif
}



void Widget::on_pushButton_quit_clicked()
{
    close();
    qApp->exit();
}

void Widget::mqtt_stateChanged_slot(QMqttClient::ClientState state)
{
    // qDebug() << "ClientState:" << state ;
    if (state == QMqttClient::Connecting)
    {
        qDebug() << "mqttclient connectting mqttserver...";

        if (!systemNetworkOnline)
        {
            ui->comboBox_server->setEnabled(true);
            ui->pushButton_open->setText(tr("网络断开，等待重连..."));
            mqttclient->disconnectFromHost();
            return;
        }

        ui->pushButton_open->setText(tr("连接中..."));
        // 连接中仍允许选择服务器，切换时会取消当前连接并连接新服务器。
        ui->comboBox_server->setEnabled(true);
    }
    else if (state == QMqttClient::Connected)
    {
        qDebug() << "mqttclient connected mqttserver";

        // 系统网络已经离线时，Connected 可能只是底层状态尚未刷新，
        // 不能把这个瞬时状态展示给用户或启动数据上报。
        if (!systemNetworkOnline)
        {
            qWarning() << "MQTT reported Connected while network is offline";
            timer->stop();
            ui->comboBox_server->setEnabled(true);
            if (!userRequestedDisconnect && ui->pushButton_open->isChecked())
                ui->pushButton_open->setText(tr("网络断开，等待重连..."));
            mqttclient->disconnectFromHost();
            return;
        }

        reconnectTimer.stop();
        ui->pushButton_open->setChecked(true);
        ui->pushButton_open->setText(tr("断开连接"));
        // 连接成功后锁定服务器选择，避免运行中修改服务器导致数据链路切换。
        ui->comboBox_server->setEnabled(false);

        // 订阅 RPC 请求主题
        QMqttSubscription *sub = mqttclient->subscribe(download_topic1 + "+");
        if (sub == nullptr)
        {
            qDebug() << "mqttclient subscribe rpc failed";
        }
        else
        {
            qDebug() << "mqttclient subscribe rpc ok";
        }

        // 订阅设备属性主题（用于接收 OTA 固件信息）
        QMqttSubscription *sub2 = mqttclient->subscribe(download_topic2);
        if (sub2 == nullptr)
        {
            qDebug() << "mqttclient subscribe attributes failed";
        }
        else
        {
            qDebug() << "mqttclient subscribe attributes ok";
        }

        QMqttSubscription *sub3 = mqttclient->subscribe(attribute_response_topic);
        if (sub3 == nullptr)
        {
            qDebug() << "mqttclient subscribe attributes response failed";
        }
        else
        {
            qDebug() << "mqttclient subscribe attributes response ok";
        }

        // 连接后主动请求最新固件属性，避免服务器未配置 retained 消息时漏掉 OTA。
        QTimer::singleShot(100, this, &Widget::requestFirmwareAttributes);

        // 启动定时器，每5000毫秒触发一次  , 开始发送数据
        timer->start(5000); //
        timer_timeout();    // 第一次触发
    }
    else if (state == QMqttClient::Disconnected)
    {
        qDebug() << "mqttclient disconnected mqttserver";
        // 断开后恢复服务器选择。
        ui->comboBox_server->setEnabled(true);

        // 关闭定时器，停止发送数据
        timer->stop(); // 关闭定时器

        if (pendingServerChange)
        {
            // 用户切换了服务器，断开旧连接后立即连接新服务器。
            pendingServerChange = false;
            userRequestedDisconnect = false;
            ui->pushButton_open->setChecked(true);
            if (systemNetworkOnline)
            {
                QTimer::singleShot(0, this, [this]() {
                    startMqttConnection();
                });
            }
            else
            {
                ui->pushButton_open->setText(tr("网络断开，等待重连..."));
            }
        }
        else if (!userRequestedDisconnect
                 && ui->pushButton_open->isChecked())
        {
            // 非用户主动断开时，延迟重连，避免连接失败造成快速循环。
            if (systemNetworkOnline)
            {
                ui->pushButton_open->setText(tr("正在重连..."));
                reconnectTimer.start();
            }
            else
            {
                ui->pushButton_open->setText(tr("网络断开，等待重连..."));
                reconnectTimer.stop();
            }
        }
        else
        {
            ui->pushButton_open->setChecked(false);
            ui->pushButton_open->setText(tr("连接服务器"));
        }
    }
}

bool Widget::isSystemNetworkOnline() const
{
    const QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
    for (const QNetworkInterface &networkInterface : interfaces)
    {
        const QNetworkInterface::InterfaceFlags flags = networkInterface.flags();
        if ((flags & QNetworkInterface::IsLoopBack)
            || !(flags & QNetworkInterface::IsUp)
            || !(flags & QNetworkInterface::IsRunning))
            continue;

        const QList<QNetworkAddressEntry> addresses =
            networkInterface.addressEntries();
        for (const QNetworkAddressEntry &address : addresses)
        {
            const QHostAddress ip = address.ip();
            if (ip.protocol() == QAbstractSocket::IPv4Protocol
                && !ip.isLoopback()
                && !ip.isNull())
                return true;
        }
    }

    return false;
}

void Widget::handleNetworkStateChanged(bool online)
{
    qDebug() << "system network state changed, online:" << online;
    systemNetworkOnline = online;

    if (!online)
    {
        // 这是异常断网，不改变用户的“保持连接”意图；网络恢复后会自动重连。
        timer->stop();
        reconnectTimer.stop();
        ui->comboBox_server->setEnabled(true);

        if (!userRequestedDisconnect && ui->pushButton_open->isChecked())
            ui->pushButton_open->setText(tr("网络断开，等待重连..."));

        if (mqttclient != nullptr
            && mqttclient->state() != QMqttClient::Disconnected)
            mqttclient->disconnectFromHost();
        return;
    }

    if (!userRequestedDisconnect && ui->pushButton_open->isChecked())
    {
        if (mqttclient == nullptr
            || mqttclient->state() == QMqttClient::Disconnected)
        {
            ui->pushButton_open->setText(tr("正在连接..."));
            reconnectTimer.start();
        }
    }
}

void Widget::mqtt_messageReceived_slot(const QByteArray &message, const QMqttTopicName &topic)
{
    qDebug() << "mqtt_messageReceived_slot:" << message;
    qDebug() << "topic.name:" << topic.name();
    // "v1/devices/me/rpc/request/4"
    // "v1/devices/me/rpc/request/5"
    // "v1/devices/me/rpc/request/6"
    // 匹配 "v1/devices/me/rpc/request/" 开头的主题
    if (topic.name().startsWith(download_topic1))
    {
        // qDebug() << "download_topic1:" << download_topic1;
        // qDebug() << "download topic.name:" << topic.name();
        // qDebug() << "   message:" << message;

        // {\"method\":\"led1Status\",\"params\":null}
        // {\"method\":\"led2Status\",\"params\":null}
        // {\"method\":\"io1Status\",\"params\":null}
        // {\"method\":\"beepStatus\",\"params\":null}

        // {\"method\":\"led1Set\",\"params\":true}
        // {\"method\":\"led2Set\",\"params\":true}
        // {\"method\":\"io1Set\",\"params\":true}
        // {\"method\":\"beepSet\",\"params\":true}

        // 解析json字符串并返回状态
        QJsonDocument jsonstr = QJsonDocument::fromJson(message); // 把message 转换成 json字符串
        if (!jsonstr.isNull())                                    // 判断不为空
        {
            // 收到了正确的数据
            QJsonObject jsonObject = jsonstr.object();          // 解析一个json对象， 就是解析json字符串
            QJsonValue jsonMethod = jsonObject.value("method"); // 获取方法的值
            QJsonValue jsonParams = jsonObject.value("params"); // 获取参数的值
            if (jsonMethod == "led1Status")
            {
                qDebug() << "led1Status";
                // 回复主题消息， 返回led1Status的值 , 服务器是thingsboard的规则引擎
                QJsonObject jsonObject;
                jsonObject.insert("led1Status", ui->pushButton_led1->isChecked());
                QJsonDocument doc(jsonObject);
                QByteArray payload = doc.toJson(QJsonDocument::Compact);
                if (mqttclient != nullptr)
                {
                    // 从请求主题中解析请求 ID，例如：v1/devices/me/rpc/request/4 -> 4
                    QString topicName = topic.name();
                    QString requestId = topicName.mid(download_topic1.length());
                    QString responseTopic = upload_topic2 + requestId; // v1/devices/me/rpc/response/4

                    qDebug() << "payload:" << payload;
                    qDebug() << "responseTopic:" << responseTopic;

                    mqttclient->publish(responseTopic, payload);
                }
            }
            else if (jsonMethod == "led2Status")
            {
                qDebug() << "led2Status";
                // 回复主题消息， 返回led2Status的值 , 服务器是thingsboard的规则引擎
                QJsonObject jsonObject;
                jsonObject.insert("led2Status", ui->pushButton_led2->isChecked());
                QJsonDocument doc(jsonObject);
                QByteArray payload = doc.toJson(QJsonDocument::Compact);
                if (mqttclient != nullptr)
                {
                    // 从请求主题中解析请求 ID，例如：v1/devices/me/rpc/request/4 -> 4
                    QString topicName = topic.name();
                    QString requestId = topicName.mid(download_topic1.length());
                    QString responseTopic = upload_topic2 + requestId; // v1/devices/me/rpc/response/4

                    qDebug() << "payload:" << payload;
                    qDebug() << "responseTopic:" << responseTopic;

                    mqttclient->publish(responseTopic, payload);
                }
            }
            else if (jsonMethod == "io1Status")
            {
                qDebug() << "io1Status";
                // 回复主题消息， 返回io1Status的值 , 服务器是thingsboard的规则引擎
                QJsonObject jsonObject;
                jsonObject.insert("io1Status", ui->pushButton_extio1->isChecked());
                QJsonDocument doc(jsonObject);
                QByteArray payload = doc.toJson(QJsonDocument::Compact);
                if (mqttclient != nullptr)
                {
                    // 从请求主题中解析请求 ID，例如：v1/devices/me/rpc/request/4 -> 4
                    QString topicName = topic.name();
                    QString requestId = topicName.mid(download_topic1.length());
                    QString responseTopic = upload_topic2 + requestId; // v1/devices/me/rpc/response/4

                    qDebug() << "payload:" << payload;
                    qDebug() << "responseTopic:" << responseTopic;

                    mqttclient->publish(responseTopic, payload);
                }
            }
            else if (jsonMethod == "beepStatus")
            {
                qDebug() << "beepStatus";
                // 回复主题消息， 返回beepStatus的值 , 服务器是thingsboard的规则引擎
                QJsonObject jsonObject;
                jsonObject.insert("beepStatus", ui->pushButton_beep->isChecked());
                QJsonDocument doc(jsonObject);
                QByteArray payload = doc.toJson(QJsonDocument::Compact);
                if (mqttclient != nullptr)
                {
                    // 从请求主题中解析请求 ID，例如：v1/devices/me/rpc/request/4 -> 4
                    QString topicName = topic.name();
                    QString requestId = topicName.mid(download_topic1.length());
                    QString responseTopic = upload_topic2 + requestId; // v1/devices/me/rpc/response/4

                    qDebug() << "payload:" << payload;
                    qDebug() << "responseTopic:" << responseTopic;

                    mqttclient->publish(responseTopic, payload);
                }
            }
            else if (jsonMethod == "led1Set")
            {
                qDebug() << "led1Set";
                on_pushButton_led1_clicked(jsonParams.toBool());
            }
            else if (jsonMethod == "led2Set")
            {
                qDebug() << "led2Set";
                on_pushButton_led2_clicked(jsonParams.toBool());
            }
            else if (jsonMethod == "io1Set")
            {
                qDebug() << "io1Set";
                on_pushButton_extio1_clicked(jsonParams.toBool());
            }
            else if (jsonMethod == "beepSet")
            {
                qDebug() << "beepSet";
                on_pushButton_beep_clicked(jsonParams.toBool());
            }
            else
            {
                qDebug() << "unknown method";
            }
        }
        else
        {
            qDebug() << "jsonstr is null";
        }
    }
    // 处理设备属性主题（OTA 固件信息由服务器主动下发）
    else if (topic.name() == download_topic2
             || topic.name() == attribute_response_topic)
    {
        qDebug() << "Received attributes message";
        QJsonDocument jsonDoc = QJsonDocument::fromJson(message);
        if (!jsonDoc.isNull() && jsonDoc.isObject())
        {
            QJsonObject jsonObj = jsonDoc.object();
            // ThingsBoard 下发的 shared attributes 格式可能是直接的 key-value
            // 或者包含在 "shared" 对象中
            QJsonObject shared;
            if (jsonObj.contains("shared"))
            {
                shared = jsonObj.value("shared").toObject();
            }
            else
            {
                // 直接就是属性
                shared = jsonObj;
            }
            handleFirmwareAttributes(shared);
        }
    }
}

void Widget::handleFirmwareAttributes(const QJsonObject &shared)
{
    // 检查是否包含固件属性
    if (!shared.contains("fw_title") || !shared.contains("fw_version"))
    {
        return;
    }

    QString fwTitle = shared.value("fw_title").toString();
    QString fwVersion = shared.value("fw_version").toString();
    int fwSize = shared.value("fw_size").toInt(0);
    QString fwChecksum = shared.value("fw_checksum").toString();
    QString fwChecksumAlg = shared.value("fw_checksum_algorithm").toString();

    qDebug() << "OTA: Firmware attributes received via MQTT:";
    qDebug() << "  fw_title:" << fwTitle;
    qDebug() << "  fw_version:" << fwVersion;
    qDebug() << "  fw_size:" << fwSize;
    qDebug() << "  fw_checksum:" << fwChecksum;
    qDebug() << "  fw_checksum_algorithm:" << fwChecksumAlg;

    const QString installedTitle = settings.value("Firmware/InstalledTitle")
                                       .toString().trimmed();
    const QString installedVersion = settings.value("Firmware/InstalledVersion")
                                         .toString().trimmed();

    // 当前下载任务或本地已安装的版本相同，不重复下载。
    if ((fwTitle == ota_currentFwTitle && fwVersion == ota_currentFwVersion)
        || (fwTitle == installedTitle && fwVersion == installedVersion))
    {
        qDebug() << "OTA: Same firmware version, skip download";
        return;
    }

    // 检查必要的属性
    if (fwTitle.isEmpty() || fwVersion.isEmpty() || fwSize <= 0 ||
        fwChecksum.isEmpty() || fwChecksumAlg.isEmpty())
    {
        qDebug() << "OTA: Incomplete firmware attributes";
        return;
    }

    // 记录当前版本
    ota_currentFwTitle = fwTitle;
    ota_currentFwVersion = fwVersion;

    // 显示 OTA 进度框
    ui->frame_ota->show();
    ui->frame_ota->raise();
    ui->progressBar_ota->setRange(0, 100);
    ui->progressBar_ota->setValue(0);
    ui->label_ota_status->setText(tr("OTA: 准备下载固件..."));

    // 获取下载目录和程序目录
    QDir appDir(QCoreApplication::applicationDirPath());
    QString downloadDir = QDir(appDir.absoluteFilePath("..")).absoluteFilePath("download");
    QString appDirPath = appDir.absolutePath();
    QString exeName = QFileInfo(QCoreApplication::applicationFilePath()).fileName();
    QString host = ui->comboBox_server->currentText();

    qDebug() << "OTA: Starting download...";
    qDebug() << "  Download dir:" << downloadDir;
    qDebug() << "  App dir:" << appDirPath;
    qDebug() << "  Exe name:" << exeName;

    // 开始下载
    httpOta->startDownload(host, fwTitle, fwVersion, fwSize, fwChecksum, fwChecksumAlg,
                           downloadDir, appDirPath, exeName);
}

void Widget::onOtaProgress(int percent)
{
    ui->progressBar_ota->setValue(percent);
}

void Widget::onOtaStatusMessage(const QString &msg)
{
    ui->label_ota_status->setText(msg);
}

void Widget::onOtaFinished(bool success, const QString &errorMessage)
{
    // OTA 重启退出码，MicroDesktop 检测到此退出码后自动重启程序
    const int OTA_RESTART_EXIT_CODE = 100;

    if (success)
    {
        // 在退出前持久化安装版本，重启或重新连接服务器时可正确判断版本。
        settings.setValue("Firmware/InstalledTitle", ota_currentFwTitle);
        settings.setValue("Firmware/InstalledVersion", ota_currentFwVersion);
        settings.sync();
        ui->label_ota_status->setText(tr("OTA: 安装完成，即将重启..."));
        // 使用特殊退出码，通知 MicroDesktop 重启本程序
        qApp->exit(OTA_RESTART_EXIT_CODE);
    }
    else
    {
        ui->label_ota_status->setText(tr("OTA: 失败 - %1").arg(errorMessage));
        // 3 秒后隐藏 OTA 框
        QTimer::singleShot(3000, this, [this]() {
            ui->frame_ota->hide();
        });
        // 清除版本记录，允许重试
        ota_currentFwTitle.clear();
        ota_currentFwVersion.clear();
    }
}

void Widget::requestFirmwareAttributes()
{
    if (mqttclient == nullptr || mqttclient->state() != QMqttClient::Connected)
        return;

    const QByteArray payload =
        "{\"sharedKeys\":\"fw_title,fw_version,fw_size,"
        "fw_checksum,fw_checksum_algorithm\"}";
    const qint32 packetId = mqttclient->publish(attribute_request_topic,
                                                payload, 1);
    qDebug() << "OTA: requested firmware attributes, packet id:" << packetId;
}

void Widget::on_pushButton_open_clicked(bool checked)
{
    if (checked)
    {
        userRequestedDisconnect = false;
        pendingServerChange = false;
        reconnectTimer.stop();

        if (!systemNetworkOnline)
        {
            ui->comboBox_server->setEnabled(true);
            ui->pushButton_open->setText(tr("网络断开，等待重连..."));
            return;
        }

        startMqttConnection();
    }
    else
    {
        // 记录用户主动断开，Disconnected 槽中不得再次自动连接。
        userRequestedDisconnect = true;
        pendingServerChange = false;
        reconnectTimer.stop();
        timer->stop();
        ui->comboBox_server->setEnabled(true);
        ui->pushButton_open->setText(tr("连接服务器"));
        if (mqttclient != nullptr)
        {
            if (mqttclient->state() != QMqttClient::Disconnected)
                mqttclient->disconnectFromHost();
        }
        else
        {
            ui->pushButton_open->setText(tr("连接服务器"));
            ui->comboBox_server->setEnabled(true);
        }
    }
}

void Widget::startMqttConnection()
{
    if (!systemNetworkOnline)
    {
        ui->comboBox_server->setEnabled(true);
        ui->pushButton_open->setChecked(true);
        ui->pushButton_open->setText(tr("网络断开，等待重连..."));
        return;
    }

    if (mqttclient != nullptr)
    {
        if (mqttclient->state() == QMqttClient::Connected
            || mqttclient->state() == QMqttClient::Connecting)
            return;
    }

    if (mqttclient == nullptr)
    {
        mqttclient = new QMqttClient(this);

        // 只连接一次信号，后续重连复用同一个 QMqttClient。
        connect(mqttclient, &QMqttClient::stateChanged,
                this, &Widget::mqtt_stateChanged_slot);
        connect(mqttclient, &QMqttClient::messageReceived,
                this, &Widget::mqtt_messageReceived_slot);
        connect(mqttclient, &QMqttClient::errorChanged, this,
                [this](QMqttClient::ClientError error) {
                    qWarning() << "mqtt error code:" << error;

                    // errorChanged 有时会先于 stateChanged 到达。先清理
                    // 数据上报和界面状态，避免旧连接仍显示为已连接。
                    if (error != QMqttClient::NoError
                        && !userRequestedDisconnect
                        && mqttclient != nullptr
                        && mqttclient->state() != QMqttClient::Disconnected)
                    {
                        timer->stop();
                        ui->comboBox_server->setEnabled(true);
                        ui->pushButton_open->setChecked(true);
                        ui->pushButton_open->setText(tr("连接异常，正在重连..."));
                        mqttclient->disconnectFromHost();
                    }
                });
    }

    // 连接失败后复用同一个 QMqttClient，避免旧客户端的异步信号干扰重连。
    QString host = ui->comboBox_server->currentText().trimmed();
    if (host.isEmpty())
        host = QStringLiteral("xthings.cloud");
    mqttclient->setHostname(host);
    mqttclient->setPort(1883);
    QString token = settings.value("Tocken/tocken").toString().trimmed();
    if (token.isEmpty())
        token = settings.value("Token/token").toString().trimmed();
    // 兼容板端未同步 Desktop.conf 的情况；配置文件中的 token 优先使用。
    if (token.isEmpty())
        token = QStringLiteral("B08ccOGYZNXPlOxqwRXx");
    qDebug() << "mqtt server:" << mqttclient->hostname();
    qDebug() << "mqtt token configured:" << !token.isEmpty()
             << "length:" << token.size();
    mqttclient->setUsername(token);
    mqttclient->setPassword("");
    // 缩短 MQTT 保活周期，让无网络时更快收到断线状态。
    mqttclient->setKeepAlive(15);

    ui->pushButton_open->setText(tr("连接中..."));
    ui->pushButton_open->setChecked(true);
    mqttclient->connectToHost();
}

void Widget::handleServerChanged(int index)
{
    Q_UNUSED(index);
    if (mqttclient == nullptr)
        return;

    if (mqttclient->state() == QMqttClient::Connected
        || mqttclient->state() == QMqttClient::Connecting)
    {
        qDebug() << "server changed, reconnect to:"
                 << ui->comboBox_server->currentText();
        pendingServerChange = true;
        userRequestedDisconnect = false;
        reconnectTimer.stop();
        mqttclient->disconnectFromHost();
    }
}


void Widget::on_pushButton_led1_clicked(bool checked)
{
    qDebug() << "led1 clicked=" << checked;
    if (checked) // led1 on
    {
        (void)system("echo 1 > /sys/class/leds/led1/brightness"); // 系统调用
        ui->pushButton_led1->setStyleSheet(
            "QPushButton#pushButton_led1 {"
            "  border: none;"
            "  border-image: url(:/images/led1on.png) 1 1 1 1 stretch stretch;"
            "}");
    }
    else // led1 off
    {
        (void)system("echo 0 > /sys/class/leds/led1/brightness"); // 系统调
        ui->pushButton_led1->setStyleSheet(
            "QPushButton#pushButton_led1 {"
            "  border: none;"
            "  border-image: url(:/images/led1off.png) 1 1 1 1 stretch stretch;"
            "}");
    }
}

void Widget::on_pushButton_led2_clicked(bool checked)
{
    qDebug() << "led2 clicked=" << checked;
    if (checked) // led2 on
    {
        (void)system("echo 1 > /sys/class/leds/led2/brightness"); // 系统调用
        ui->pushButton_led2->setStyleSheet(
            "QPushButton#pushButton_led2 {"
            "  border: none;"
            "  border-image: url(:/images/led2on.png) 1 1 1 1 stretch stretch;"
            "}");
    }
    else // led2 off
    {
        (void)system("echo 0 > /sys/class/leds/led2/brightness"); // 系统调用
        ui->pushButton_led2->setStyleSheet(
            "QPushButton#pushButton_led2 {"
            "  border: none;"
            "  border-image: url(:/images/led2off.png) 1 1 1 1 stretch stretch;"
            "}");
    }
}

void Widget::on_pushButton_beep_clicked(bool checked)
{
    qDebug() << "beep clicked=" << checked;
    if (checked) // beep on
    {
        (void)system("echo 1 > /sys/class/leds/beep/brightness"); // 系统调用
        ui->pushButton_beep->setStyleSheet(
            "QPushButton#pushButton_beep {"
            "  border: none;"
            "  border-image: url(:/images/beepon.png) 1 1 1 1 stretch stretch;"
            "}");
    }
    else // beep off
    {
        (void)system("echo 0 > /sys/class/leds/beep/brightness"); // 系统调用
        ui->pushButton_beep->setStyleSheet(
            "QPushButton#pushButton_beep {"
            "  border: none;"
            "  border-image: url(:/images/beepoff.png) 1 1 1 1 stretch stretch;"
            "}");
    }
}

void Widget::on_pushButton_extio1_clicked(bool checked)
{
    qDebug() << "extio1 clicked=" << checked;
    if (checked) // extio1 on
    {
        (void)system("echo 1 > /sys/class/leds/extio1/brightness"); // 系统调用
        ui->pushButton_extio1->setStyleSheet(
            "QPushButton#pushButton_extio1 {"
            "  border: none;"
            "  border-image: url(:/images/extio1on.png) 1 1 1 1 stretch stretch;"
            "}");
    }
    else // extio1 off
    {
        (void)system("echo 0 > /sys/class/leds/extio1/brightness"); // 系统调用
        ui->pushButton_extio1->setStyleSheet(
            "QPushButton#pushButton_extio1 {"
            "  border: none;"
            "  border-image: url(:/images/extio1off.png) 1 1 1 1 stretch stretch;"
            "}");
    }
}


void Widget::initUi()
{
    // OTA 进度框默认隐藏
    ui->frame_ota->hide();

    // 绘制背景图片
    QPalette PAllbackground = this->palette();
    QImage ImgAllbackground(QString::fromUtf8(":/images/back.png"));
    QImage pix = ImgAllbackground.scaled(this->size(), Qt::IgnoreAspectRatio);
    PAllbackground.setBrush(QPalette::Window, QBrush(pix));
    this->setPalette(PAllbackground);

    QFont font;
    font.setFamily(QString::fromUtf8("Noto Sans CJK SC"));
    font.setPointSize(18);
    font.setBold(true);

    // led1：使用样式表按按钮大小缩放背景图
    ui->pushButton_led1->setStyleSheet(
        "QPushButton#pushButton_led1 {"
        "  border: none;"
        "  border-image: url(:/images/led1off.png) 1 1 1 1 stretch stretch;"
        "}");

    // led2：使用样式表按按钮大小缩放背景图
    ui->pushButton_led2->setStyleSheet(
        "QPushButton#pushButton_led2 {"
        "  border: none;"
        "  border-image: url(:/images/led2off.png) 1 1 1 1 stretch stretch;"
        "}");

    // extio1：使用样式表按按钮大小缩放背景图
    ui->pushButton_extio1->setStyleSheet(
        "QPushButton#pushButton_extio1 {"
        "  border: none;"
        "  border-image: url(:/images/extio1off.png) 1 1 1 1 stretch stretch;"
        "}");

    // beep ：使用样式表按按钮大小缩放背景图
    ui->pushButton_beep->setStyleSheet(
        "QPushButton#pushButton_beep {"
        "  border: none;"
        "  border-image: url(:/images/beepoff.png) 1 1 1 1 stretch stretch;"
        "}");

    // temp：使用样式表按按钮大小缩放背景图
    ui->pushButton_temp->setStyleSheet(
        "QPushButton#pushButton_temp {"
        "  border: none;"
        "  border-image: url(:/images/temp.png) 1 1 1 1 stretch stretch;"
        "  color: white;"
        "  text-align: right;"
        "  padding-right: 12px;"
        "  padding-top: 30px;"
        "}");
    ui->pushButton_temp->setFont(font);

    // hum：使用样式表按按钮大小缩放背景图
    ui->pushButton_hum->setStyleSheet(
        "QPushButton#pushButton_hum {"
        "  border: none;"
        "  border-image: url(:/images/hum.png) 1 1 1 1 stretch stretch;"
        "  color: white;"
        "  text-align: right;"
        "  padding-right: 12px;"
        "  padding-top: 30px;"
        "}");
    ui->pushButton_hum->setFont(font);

    // vr：使用样式表按按钮大小缩放背景图
    ui->pushButton_vr->setStyleSheet(
        "QPushButton#pushButton_vr {"
        "  border: none;"
        "  border-image: url(:/images/vr.png) 1 1 1 1 stretch stretch;"
        "  color: white;"
        "  text-align: right;"
        "  padding-right: 15px;"
        "  padding-top: 30px;"
        "}");
    ui->pushButton_vr->setFont(font);

    // vol：使用样式表按按钮大小缩放背景图
    ui->pushButton_vol->setStyleSheet(
        "QPushButton#pushButton_vol {"
        "  border: none;"
        "  border-image: url(:/images/vol.png) 1 1 1 1 stretch stretch;"
        "  color: white;"
        "  text-align: right;"
        "  padding-right: 15px;"
        "  padding-top: 30px;"
        "}");
    ui->pushButton_vol->setFont(font);

    // cur：使用样式表按按钮大小缩放背景图
    ui->pushButton_cur->setStyleSheet(
        "QPushButton#pushButton_cur {"
        "  border: none;"
        "  border-image: url(:/images/cur.png) 1 1 1 1 stretch stretch;"
        "  color: white;"
        "  text-align: right;"
        "  padding-right: 12px;"
        "  padding-top: 30px;"
        "}");
    ui->pushButton_cur->setFont(font);

    // pw：使用样式表按按钮大小缩放背景图
    ui->pushButton_pw->setStyleSheet(
        "QPushButton#pushButton_pw {"
        "  border: none;"
        "  border-image: url(:/images/pw.png) 1 1 1 1 stretch stretch;"
        "  color: white;"
        "  text-align: right;"
        "  padding-right: 12px;"
        "  padding-top: 30px;"
        "}");
    ui->pushButton_pw->setFont(font);

    // cpu：使用样式表按按钮大小缩放背景图
    ui->pushButton_cpu->setStyleSheet(
        "QPushButton#pushButton_cpu {"
        "  border: none;"
        "  border-image: url(:/images/cpu.png) 1 1 1 1 stretch stretch;"
        "  color: white;"
        "  text-align: right;"
        "  padding-right: 12px;"
        "  padding-top: 30px;"
        "}");
    ui->pushButton_cpu->setFont(font);
    // quit：使用样式表按按钮大小缩放背景图
    ui->pushButton_quit->setStyleSheet(
        "QPushButton#pushButton_quit {"
        "  border: none;"
        "  border-image: url(:/images/quit.png) 1 1 1 1 stretch stretch;"
        "}");
}
